# 5p_clothes - Clothing Menu

This is a free release from 5Point Resources.

It includes a config file where you can edit the index of the clothing components to take off (if you have mods in the server).
Give us credits if you're using it by saving the name of the resource as it is.

You can visit our website in https://5point.dev or contact us on discord (https://discord.5point.dev).

Resource preview: https://youtu.be/oAW0de2bCqk

Hope you like it!
